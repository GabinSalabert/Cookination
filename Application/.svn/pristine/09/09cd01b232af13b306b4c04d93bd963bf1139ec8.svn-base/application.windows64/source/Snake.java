import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import com.dhchoi.*; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Snake extends PApplet {






Jeu jeu;
AudioPlayer player, player2, player3;
Minim minim;//audio context
CountdownTimer timer;
String timerCallbackInfo = "";





// Create the window and initialize positions, font-family, FPS.. \\

public void setup() {
   //Window's size (+1 for edges)
  jeu = new Jeu();

  minim = new Minim(this);
  player = minim.loadFile("Happy-electronic-music.mp3", 2048);
  player2 = minim.loadFile("Casual-friday-electronic-beat-music.mp3", 2048);
  player3 = minim.loadFile("fail-trombone-01.mp3", 2048);
  timer = CountdownTimerService.getNewCountdownTimer(this).configure(1000, 60000);
  frameRate(60); //FPS
}




  public void onTickEvent(CountdownTimer t, long timeLeftUntilFinish) {
    timerCallbackInfo = "TimeLeft: " + timeLeftUntilFinish/1000 + "s";
  }

  public void onFinishEvent(CountdownTimer t) {
    timerCallbackInfo = "[finished]";
    jeu.over = true;
  }






// Specific tests to catch events and which key is hit

public void keyPressed() { //Direction in case of event
  if (!jeu.over && !jeu.turn) {
    jeu.turn = true;
    if (keyCode == 38 && (jeu.dir == 1 || jeu.dir == 3)) jeu.dir = 0; //Top
    if (keyCode == 40 && (jeu.dir == 1 || jeu.dir == 3)) jeu.dir = 2; //Bottom
    if (keyCode == 37 && (jeu.dir == 0 || jeu.dir == 2)) jeu.dir = 3; //Left
    if (keyCode == 39 && (jeu.dir == 0 || jeu.dir == 2)) jeu.dir = 1; //Rigth
  }
  if (!jeu.over && !jeu.turn2) {
    jeu.turn2 = true;
    if (key == 'z' && (jeu.dir2 == 1 || jeu.dir2 == 3)) jeu.dir2 = 0; //Top
    if (key == 's' && (jeu.dir2 == 1 || jeu.dir2 == 3)) jeu.dir2 = 2; //Bottom
    if (key == 'q' && (jeu.dir2 == 0 || jeu.dir2 == 2)) jeu.dir2 = 3; //Left
    if (key == 'd' && (jeu.dir2 == 0 || jeu.dir2 == 2)) jeu.dir2 = 1; //Rigth
  }

  if (key == 'm' && jeu.music == true) {
    if (jeu.unJoueur == 0 && jeu.deuxJoueur == 0) {
      player.mute();
    }

    if (jeu.unJoueur == 1 || jeu.deuxJoueur == 2) {
      player2.mute();
    }
    jeu.music = false;
  }

  if (key == 'p' && jeu.music == false) {
    if (jeu.unJoueur == 1 || jeu.deuxJoueur == 2) {
      player2.unmute();
    }
    if (jeu.unJoueur == 0 && jeu.deuxJoueur == 0) {
      player.unmute();
    }
    jeu.music = true;
  }
}







//Draw all we need, 

public void draw() {
  jeu.draw();
  if (jeu.retry == 42) {
    jeu = new Jeu();
    println(jeu.unJoueur);
    println(jeu.deuxJoueur);
    println(jeu.retry);
  }
}
class Body {
  int x = 0;
  int y = 0;

  //Constructor with body's positions
  public Body(int posx, int posy) {
    x = posx;
    y = posy;
  }

  //Initialization of positions
  public void setX(int v) { 
    x=v;
  }

  public void setY(int v) {
    y=v;
  }

  //Return positions
  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }
}
class Button {
  float x;
  float y;
  float w; 
  float h;
  int z;

  public Button(float _x, float _y, float _w, float _h) {
    x = _x;
    y = _y;
    w = _w;
    h = _h;
  }

  public void drawBe() {
    fill(0, 0, 0);
    rect(x, y, w, h);
    stroke(150, 150, 150);
    strokeWeight(3);
    rect(x, y, w, h);
    fill(150, 150, 150);
    text("Exit", x+61, y+20);
  }

  public void drawBr() {
    fill(0, 0, 0);
    rect(x, y, w, h);
    stroke(150, 150, 150);
    strokeWeight(3);
    rect(x, y, w, h);
    fill(150, 150, 150);
    text("Retry", x+61, y+20);
  }
  
  public void drawBs() {
    fill(0, 0, 0);
    rect(x, y, w, h);
    stroke(150, 150, 150);
    strokeWeight(3);
    rect(x, y, w, h);
    fill(150, 150, 150);
    text("Solo", x+61, y+20);
  }
  
  public void drawBd() {
    fill(0, 0, 0);
    rect(x, y, w, h);
    stroke(150, 150, 150);
    strokeWeight(3);
    rect(x, y, w, h);
    fill(150, 150, 150);
    text("Duo", x+61, y+20);
  }

  public void quit() {
    if (mousePressed) {
      if (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h) {
        println("Ok, quitting.");
        exit();
      }
    }
  }
  
  public int retry() {
    if (mousePressed) {
      if (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h) {
        println("Ok, retrying.");
        println(jeu.unJoueur);
        println(jeu.deuxJoueur);
        return 42;
      }
    }
    return 0;
  }
  
  public int playS() {
    if (mousePressed) {
      if (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h) {
         return 1;
      }
    }
    
    return 0;
  }
  
  public int playD() {
    if (mousePressed) {
      if (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h) {
         return 2;
      }
    }
    
    return 0;
  }
}
public class Jeu {
  int head[] = new int[2];
  int head2[] = new int[2];

  int item[] = new int[2];
  int frame = 0;
  int retry;
  int sec = second(); 
  int min = minute(); 
  int h = hour(); 


  int bodyLength = 2;//first length, at the beginning
  int bodyLength2 = 2;
  int dir = 0, dir2 = 0, score, score2, state = 0, m, unJoueur, deuxJoueur;

  Body body[] = new Body[5000]; //Max length for snake
  Body body2[] = new Body[5000];

  Button buttonExit = new Button(300, 300, 120, 50);
  Button buttonRetry = new Button(300, 370, 120, 50);
  Button buttonSolo = new Button(100, 320, 120, 50);
  Button buttonDuo = new Button(500, 320, 120, 50);

  boolean over = false; //False value until game's end
  boolean turn = false; //A little bug if you hit 2 keys in the same time, the snakes makes a half turn
  boolean turn2 = false;
  boolean loose1 = false;
  boolean loose2 = false;
  boolean music = true;

  PImage img, img2;


  public Jeu() {
    //Snake's head position
    head[0] = PApplet.parseInt(width/20);
    head[1] = PApplet.parseInt(height/20);
    head2[0] = PApplet.parseInt(width/15);
    head2[1] = PApplet.parseInt(height/15);

    //item's position
    item[0] = PApplet.parseInt(random(width/10));
    item[1] = PApplet.parseInt(random(height/10));

    //Snake's body positions
    body[0] = new Body(head[0], head[1]+1); //Obligatory else it's over
    body[1] = new Body(head[0], head[1]+2); //Obligatory else it's over
    body2[0] = new Body(head2[0], head2[1]+1); 
    body2[1] = new Body(head2[0], head2[1]+2);

    textFont(createFont("Time New Roman", 30)); //Choose a font-family
    textAlign(CENTER, CENTER); //Choose where you want it

    img = loadImage("Ban4.jpg");
    img2 = loadImage("Snake.jpeg");
  
    retry = 0;
    unJoueur = 0;
    deuxJoueur = 0;
    score = 0;
    score2 = 0;
  }







  // Lauch the game, draw all we want (snake, item..) and allows moves. Also do some test for the game's end \\
  public void draw() {
    int i, j;

    //Create the canva
    if (unJoueur == 0 && deuxJoueur == 0) {
      player.play();
      image(img2, 0, 0, width, height);
      stroke(150);
      rect(0, 0, width, 94);
      image(img, 0, 3);
      buttonSolo.drawBs();
      buttonDuo.drawBd();
      unJoueur = buttonSolo.playS();
      deuxJoueur = buttonDuo.playD();
    }





    //Mode Solo

    else if (unJoueur == 1) { 
      deuxJoueur = 0;
      retry = 0;
      player.close();
      player2.play();
      background(0);
      fill(30); //Grey color for grid
      noStroke(); 
      for (i=0; i < 73; i++) { //Browse Width
        for (j=0; j < 48; j++) { //Browse Height
          rect(i*10+1, j*10+1, 9, 9); //Create the grid //"9" else last squares will be on the edge
        }
      }

      fill(0, 0, 255); //Blue color
      ellipse(item[0]*10+5.5f, item[1]*10+5.5f, 9, 9); //Float numbers because we want the case's center for the ellipse

      fill(255, 0, 0); //Red color
      rect(head[0]*10+1, head[1]*10+1, 9, 9); //Draw snake's head

      fill(255, 255, 0); //Yellow colors
      for (i=0; i < bodyLength; i++) { //Browse the snale's body
        rect(body[i].getX()*10+1, body[i].getY()*10+1, 9, 9); //Draw snake's body
        if (body[i].getX() == head[0] && body[i].getY() == head[1]) over = true; //If the snake eats himself, it's lost
      }

      if (!over) {

        if (frame == 5) {
          for (int k = bodyLength-1; k > 0; k--) { //Browse the body but upside down and without the head. The body has to follow the head
            body[k].setX(body[k-1].getX()); //Set the body[i] position with the body[i-1] position (x)
            body[k].setY(body[k-1].getY()); //Set the body[i] position with the body[i-1] position (y)
          }

          body[0].setX(head[0]); //Set the body's first part with the head position (x) 
          body[0].setY(head[1]); //Set the body's first part with the head position (x)

          if (dir == 0) head[1] --; //Move head towards top
          else if (dir == 1) head[0] ++; //Move head towards rigth
          else if (dir == 2) head[1] ++; //Move head towards bottom
          else head[0] --; //Move head towards left
        }
        frame = (frame+1) % 6;
        if (head[0] == item[0] && head[1] == item[1]) {
          score++;
          item[0] = PApplet.parseInt(random(width/10));
          item[1] = PApplet.parseInt(random(height/10));
          body[bodyLength] = new Body(body[bodyLength-1].getX(), body[bodyLength-1].getY()); //Create a new part in the snake's body, placed at the end
          bodyLength ++; //Don't forget to increment the snake's size in this case
        }

        if (head[0] == -1 || head[0] == 73 || head[1] == -1 || head[1] == 48) over = true;

        fill(255); 
        text("Score : "+score, width/2, 10); //Write the message
      } 
      
      else {
        player2.close();
        player3.play();
        fill(0, 200);
        rect(0, 0, width, height);
        fill(255); //Dark shadow

        //Write the message after loosing
        if (score < 10) { 
          fill(150, 150, 150);
          text("Score : "+score + "\nYou're so bad, try again..", width/2, height/3);
        } else if (score >= 10 && score < 20) { 
          fill(150, 150, 150);
          text("Score : "+score + "\nNot bad dude,\n but not enough to impress me..", width/2, height/3);
        } else if (score >= 20) { 
          fill(150, 150, 150);
          text("Score : "+score + "\nWow! Well, I think I can say that : ggwp!", width/2, height/3);
        }

        //Draw the button Quit
        buttonExit.drawBe();
        buttonRetry.drawBr();
        buttonExit.quit();  
        this.retry = buttonRetry.retry();

        
      }

      turn = false;
    }

















    //Mode Duo
   
    else if (deuxJoueur == 2) {
      timer.start();
      retry = 0;
      unJoueur = 0;
      player.close();
      player2.play();
      background(0);
      fill(30); //Grey color for grid
      noStroke(); 
      for (i=0; i < 73; i++) { //Browse Width
        for (j=0; j < 48; j++) { //Browse Height
          rect(i*10+1, j*10+1, 9, 9); //Create the grid //"9" else last squares will be on the edge
        }
      }

      fill(0, 0, 255); //Blue color
      ellipse(item[0]*10+5.5f, item[1]*10+5.5f, 9, 9); //Float numbers because we want the case's center for the ellipse

      fill(255, 0, 0); //Red color
      rect(head[0]*10+1, head[1]*10+1, 9, 9); //Draw snake's head
      fill(0, 255, 0);
      rect(head2[0]*10+1, head2[1]*10+1, 9, 9); //Draw snake's head

      fill(255, 255, 0); //Yellow colors
      for (i=0; i < bodyLength; i++) { //Browse the snale's body
        rect(body[i].getX()*10+1, body[i].getY()*10+1, 9, 9); //Draw snake's body
        if (body[i].getX() == head[0] && body[i].getY() == head[1]) over = true; //If the snake eats himself, it's lost
        for (m=0; m < bodyLength2; m++) {
          if (body2[m].getX() == head[0] && body2[m].getY() == head[1]) {
            over = true; 
            loose1 = true;
          }
        }
      }
      fill(0, 255, 255); 
      for (m=0; m < bodyLength2; m++) { //Browse the snale's body
        rect(body2[m].getX()*10+1, body2[m].getY()*10+1, 9, 9); //Draw snake's body
        if (body2[m].getX() == head2[0] && body2[m].getY() == head2[1]) over = true; //If the snake eats himself, it's lost
        for (i=0; i < bodyLength; i++) {
          if (body[i].getX() == head2[0] && body[i ].getY() == head2[1]) {
            over = true; 
            loose2 = true;
          }
        }
      }

      if (!over) {
        if (frame == 5) {
          for (int k = bodyLength-1; k > 0; k--) { //Browse the body but upside down and without the head. The body has to follow the head
            body[k].setX(body[k-1].getX()); //Set the body[i] position with the body[i-1] position (x)
            body[k].setY(body[k-1].getY()); //Set the body[i] position with the body[i-1] position (y)
          }
          for (int l = bodyLength2-1; l > 0; l--) { //Browse the body but upside down and without the head. The body has to follow the head
            body2[l].setX(body2[l-1].getX()); //Set the body[i] position with the body[i-1] position (x)
            body2[l].setY(body2[l-1].getY()); //Set the body[i] position with the body[i-1] position (y)
          }

          body[0].setX(head[0]); //Set the body's first part with the head position (x) 
          body[0].setY(head[1]); //Set the body's first part with the head position (x)
          body2[0].setX(head2[0]);
          body2[0].setY(head2[1]);

          if (dir == 0) head[1] --; //Move head towards top
          else if (dir == 1) head[0] ++; //Move head towards rigth
          else if (dir == 2) head[1] ++; //Move head towards bottom
          else head[0] --; //Move head towards left

          if (dir2 == 0) head2[1] --; //Move head towards top
          else if (dir2 == 1) head2[0] ++; //Move head towards rigth
          else if (dir2 == 2) head2[1] ++; //Move head towards bottom
          else head2[0] --; //Move head towards left
        }

        frame = (frame+1) %6;
        if (head[0] == item[0] && head[1] == item[1]) {
          score++;
          item[0] = PApplet.parseInt(random(width/10));
          item[1] = PApplet.parseInt(random(height/10));
          body[bodyLength] = new Body(body[bodyLength-1].getX(), body[bodyLength-1].getY()); //Create a new part in the snake's body, placed at the end
          bodyLength ++; //Don't forget to increment the snake's size in this case
        }
        if (head2[0] == item[0] && head2[1] == item[1]) {
          score2++;
          item[0] = PApplet.parseInt(random(width/10));
          item[1] = PApplet.parseInt(random(height/10));
          body2[bodyLength] = new Body(body2[bodyLength2-1].getX(), body2[bodyLength2-1].getY()); //Create a new part in the snake's body, placed at the end
          bodyLength2 ++; //Don't forget to increment the snake's size in this case
        }

        if (head[0] == -1 || head[0] == 72 || head[1] == -1 || head[1] == 48) {
          over = true;
          loose1 = true;
        }
        if (head2[0] == -1 || head2[0] == 72 || head2[1] == -1 || head2[1] == 48) {
          over = true;
          loose2 = true;
        }

        text(timerCallbackInfo, width/2, height/11);
        fill(255); 
        
      } 
      
      else {
        
        timer.reset();
        
        player2.close();
        player3.play();
        fill(0, 200);
        rect(0, 0, width, height);
        fill(255); //Dark shadow

        //Write the message after loosing
        if (loose1) { 
          fill(150, 150, 150);
          text("Score Joueur 1 : "+score + "\nScore Joueur 2 : "+score2 + "\nThe winner is Joueur : 2.", width/2, height/3);
        }
        if (loose2) { 
          fill(150, 150, 150);
          text("Score Joueur 1 : "+score + "\nScore Joueur 2 : "+score2 + "\nThe winner is Joueur : 1.", width/2, height/3);
        }

        //Draw the button Quit
        buttonExit.drawBe();
        buttonRetry.drawBr();
        buttonExit.quit();  
        this.retry = buttonRetry.retry();
        
      }
      

      turn = false;
      turn2 = false;
    }
  }
}
  public void settings() {  size(728, 481); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Snake" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
